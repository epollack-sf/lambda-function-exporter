/****************************************************************
The purpose of this Lambda is to retrive all the tax related config
data and determine IF current date is within is within Tax Range.
If so, determine the specific Range 1/2/3 and pass all that information
back to the contact flow which then can use it for branching and/or 
as criteria for specific read outs.

input: 
output: TaxRange_Dec31RMD, TaxRange1_Dec31RMD, TaxRange2_Dec31RMD,
        TaxRange3_Dec31RMD, TaxRange1_TaxForms, TaxRange2_TaxForms


Created By  - VH, EP
Release     - Version 2
Date        -  
Deployment Notes:
 * 1. Dynamo DB, 2. Lambda ->Config->Permissions-> click on RoleName
 * give AmazonDynamoDBReadOnlyAccess permission
****************************************************************/

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { ScanCommand } from "@aws-sdk/lib-dynamodb";

const ERROR = {
    TaxRange_Dec31RMD: null,
    TaxRange1_Dec31RMD: null,
    TaxRange2_Dec31RMD: null,
    TaxRange3_Dec31RMD: null,
    TaxRange1_TaxForms: null,
    TaxRange2_TaxForms: null,
    taxSeasonBegin: null,
    taxSeasonEnd: null,
    taxFormsReceived: null,
    taxFormsImaged: null,
    rmdCalcEnd: null
};

const client = new DynamoDBClient({});

// Builds date object from test date string
// Returns current date object if no test date is entered
const getDateObject = (testDateString) => {
    if (!testDateString?.length) return new Date();
    const dateObject = parseISODateString(testDateString);
    
    return dateObject.getTime() ? dateObject : new Date();
};

// Parses and creates objects from ISO date string with or without year
const parseISODateString = (dateString, year=null) => {
    const dateStringParts = dateString.split('-');
    const monthIndex = dateStringParts.length - 2;
    const dayIndex = dateStringParts.length - 1;
    const dateStringEpoch = Date.UTC(year || dateStringParts[0], 
        Number(dateStringParts[monthIndex]) - 1, Number(dateStringParts[dayIndex]));
    
    return new Date(dateStringEpoch);
};

const buildISODateString = (date) => {
    const mm = date.getUTCMonth() + 1;
    const monthPrefix = (mm < 10) ? '0' : '';
    const dd = date.getUTCDate();
    const datePrefix = (dd < 10) ? '0' : '';
    const yyyy = date.getUTCFullYear();
    
    return `${yyyy}-${monthPrefix + mm}-${datePrefix + dd}`;
};

const getTaxConfigs = async () => {
    return await client.send(new ScanCommand({
        FilterExpression: "ID > :idval",
        ExpressionAttributeValues: {
          ":idval": 0,
        },
        ProjectionExpression: "Setting, DateValue",
        TableName: "SS_ACCLCC_Tax_Config",
    }));
};

const generateDec31Values = (settings, year) => {
    const dec31Reducer = (accumulator, currentValue) => {
        const { Setting, DateValue } = currentValue;
        const dateValueObject = parseISODateString(DateValue, year);

        return { ...accumulator, [Setting]: dateValueObject };
    };
    
    return settings.Items.reduce(dec31Reducer, {});
};

const dayAfter = (date) => new Date(date.getUTCFullYear(), 
    date.getUTCMonth(), date.getUTCDate() + 1);

const stringifyBooleans = (obj) => {
    for (const [k,v] of Object.entries(obj)) {
        if (typeof v !== 'boolean') continue;
        obj[k] = v.toString();
    }

    return obj;
};

export const handler = async (event) => {
    let taxConfigs;
    try {
        taxConfigs = await getTaxConfigs();
    } catch {
        return ERROR;
    }
    
    const { Details: { Parameters: { input_testTaxDate: testDate } = {} } } = event;
    const currentDate = getDateObject(testDate);
    const currentYear = currentDate.getUTCFullYear();
    
    const dec31Values = generateDec31Values(taxConfigs, currentYear);
    const { taxSeasonBegin, 
            rmdCalcEnd, 
            fmvLettersImaged, 
            taxSeasonEnd, 
            taxFormsReceived, 
            taxFormsImaged
    } = dec31Values;

    // Determine RMD Ranges
    const rmdRange1 = (currentDate >= taxSeasonBegin) && 
        (currentDate <= rmdCalcEnd);
    const rmdRange2 = (currentDate >= dayAfter(rmdCalcEnd)) && 
        (currentDate <= fmvLettersImaged);
    const rmdRange3 = (currentDate >= dayAfter(fmvLettersImaged)) && 
        (currentDate <= taxSeasonEnd);
    const rmdRange = rmdRange1 || rmdRange2 || rmdRange3;

    // Determine Form Ranges
    const formRange1 = (currentDate >= taxSeasonBegin) && 
        (currentDate <= taxFormsImaged);
    const formRange2 = (currentDate >= dayAfter(taxFormsImaged)) && 
        (currentDate <= taxFormsReceived);

    // Format Date Output
    const formattedRMDCalcEnd = buildISODateString(rmdCalcEnd);
    const formattedTaxFormsImaged = buildISODateString(taxFormsImaged);
    const formattedTaxFormsReceived = buildISODateString(taxFormsReceived);
    const formattedTaxSeasonEnd = buildISODateString(taxSeasonEnd);
    const formattedTaxSeasonBegin = buildISODateString(taxSeasonBegin);

    return stringifyBooleans({
        TaxRange_Dec31RMD: rmdRange,
        TaxRange1_Dec31RMD: rmdRange1,
        TaxRange2_Dec31RMD: rmdRange2,
        TaxRange3_Dec31RMD: rmdRange3,
        TaxRange1_TaxForms: formRange1,
        TaxRange2_TaxForms: formRange2,
        taxSeasonBegin: formattedTaxSeasonBegin,
        taxSeasonEnd: formattedTaxSeasonEnd,
        taxFormsReceived: formattedTaxFormsReceived,
        taxFormsImaged: formattedTaxFormsImaged,
        rmdCalcEnd: formattedRMDCalcEnd
    });
};