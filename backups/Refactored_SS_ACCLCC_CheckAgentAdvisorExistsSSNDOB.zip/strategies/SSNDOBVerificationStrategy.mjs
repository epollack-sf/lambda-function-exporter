class SSNDOBVerificationStrategy {
    transactionId;
    ssn;
    dob; // YYYY-MM-DD
    lineOfBusiness;
    updateEndpoint;
    domainProperty;

    get dobEpoch() {
        const parts = this.dob.split('-');
        
        return Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    }

    constructor(tid, ssn, dob, lineOfBusiness, endpoint, property) {
        this.transactionId = tid;
        this.ssn = ssn;
        this.dob = dob;
        this.lineOfBusiness = lineOfBusiness;
        this.updateEndpoint = endpoint;
        this.domainProperty = property;
    }
}

export default SSNDOBVerificationStrategy;