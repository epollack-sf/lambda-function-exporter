import SSNDOBVerificationStrategy from '../SSNDOBVerificationStrategy.mjs';

const UPDATE_ENDPOINT = '/advisor/active/advisors';
const DOMAIN_PROPERTY = 'advisorDomains';

class AdvisorStrategy extends SSNDOBVerificationStrategy {
    get retrievalEndpoint() {
        return `/advisor/all/advisors/transaction/${this.transactionId}/govId/${this.ssn}/dob/${this.dob}`;
    }

    constructor(tid, ssn, dob, lineOfBusiness) {
        super(tid, ssn, dob, lineOfBusiness, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }

    filterDomains(domains) {
        const actualDOB = this.dobEpoch;

        return domains.filter(domain => {
            const { authData } = domain;
            const { govtID: expectedSSN, dob: expectedDOB } = authData;
            const ssnMatch = this.ssn === expectedSSN;
            const dobMatch = actualDOB === expectedDOB;
    
            return ssnMatch && dobMatch;
        });
    }
}

export default AdvisorStrategy;