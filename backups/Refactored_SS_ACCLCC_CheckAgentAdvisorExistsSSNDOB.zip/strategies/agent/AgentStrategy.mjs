import SSNDOBVerificationStrategy from '../SSNDOBVerificationStrategy.mjs';

const ACTIVE = 'Active';
const UPDATE_ENDPOINT = '/agent/producers';
const DOMAIN_PROPERTY = 'agentDomains';

class AgentStrategy extends SSNDOBVerificationStrategy {
    get retrievalEndpoint() {
        return `/agent/all/producers/transaction/${this.transactionId}/govId/${this.ssn}/dob/${this.dob}/any`;
    }

    constructor(tid, ssn, dob, lineOfBusiness) {
        super(tid, ssn, dob, lineOfBusiness, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }

    filterDomains(domains) {
        const actualDOB = this.dobEpoch;

        return domains.filter(domain => {
            const { authData } = domain;
            const { lineOfBusiness, status, govtID: expectedSSN, dob: expectedDOB } = authData;
            const { description: lobDescription } = lineOfBusiness;
            const { description: statusDescription } = status;
    
            const lobMatch = lobDescription === this.lineOfBusiness;
            const statusMatch = statusDescription === ACTIVE;
            const ssnMatch = this.ssn === expectedSSN;
            const dobMatch = actualDOB === expectedDOB;
    
            return lobMatch && statusMatch && ssnMatch && dobMatch;
        });
    }
}

export default AgentStrategy;