/****************************************************************
The purpose of this Lambda is to call a basic policy API to retrieve 
minimum information. Once that is done, this call is chained with a
another core services API where we setup* to hydrate (or get all details) 
which are then later accessed through another Lambda.

*: setup means hitting the hydrate endpoint and adding an index to the 
    corresponding policy row. This allows for quick lookup when the hydrated 
    data is needed.


input: policy #
output: policyExists, transactionId


Created By  - VH, EP
Release     - Version 2
Date        - 8/28/23
****************************************************************/

import https from 'node:https';

const ODS_API_BASE_URL = process.env.ODS_API_BASE_URL; 
const ODS_API_USERNAME = process.env.ODS_API_USERNAME;
const ODS_API_PASSWORD = process.env.ODS_API_PASSWORD;
const AUTHORIZATION = `Basic ${Buffer.from(`${ODS_API_USERNAME}:${ODS_API_PASSWORD}`).toString('base64')}`;
const ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const ID_LENGTH = 32;
const REQUEST_OPTIONS = {
    method: 'GET',
    headers: {
        'Authorization': AUTHORIZATION,
        'Content-Type': 'application/json'
    }
};

const generateTransactionId = () => {
    let rtn = '';
    for (let i=0; i<ID_LENGTH; i++) {
        rtn += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
    }

    return `AC${rtn}`;
};

const callSinglePolicy = async (tid, pid) => {
    const endpoint = `${ODS_API_BASE_URL}/policy/customer/transaction/${tid}/single/policy/${pid}`;
    const result = await sendHttpsRequest(endpoint);
    if (JSON.parse(result).errorDetails) throw new Error('server error');
};

const callHydratePolicy = async (tid) => {
    const endpoint = `${ODS_API_BASE_URL}/policy/hydrate/policy/transaction/${tid}`;
    await sendHttpsRequest(endpoint);
};

const sendHttpsRequest = (url) => new Promise((resolve, reject) => {
    const cb = (res) => {
        if (res.statusCode < 200 || res.statusCode > 299) {
            reject(new Error('bad response'));
            return;
        }

        let data = '';

        res.on('data', (chunk) => data += chunk);
        res.on('end', () => resolve(data));
    };

    const req = https.request(url, REQUEST_OPTIONS, cb);
    req.on('error', (err) => reject(err));
    req.end();
});

export const handler = async (event) => {
    const { Details: { Parameters: params } = {} } = event;
    const policyId = params.customerInput_policy_Id;
    const transactionId = generateTransactionId();

    // Connect doesn't read booleans
    let policyExists = 'true';
    
    try {
        await callSinglePolicy(transactionId, policyId);
        await callHydratePolicy(transactionId);
    } catch {
        policyExists = 'false';
    }

    return { transactionId, policyExists }; 
};