import { ACCResponse,
        getHydratedData, 
        formatISODOBString, 
        buildDateString,
        datediff
} from '../utils/hydration-helper.mjs';

// Move to utils and export if needed in LCC
const NO_POLICY_RESTRICTION = '1013700000';

const verifyOwner = (roles, { input_ownerDOB: dobUnformatted, input_ownerSSN: actualSSN }) => {
    // YYYY-MM-DD to MMDDYYYY
    const actualDOB = formatISODOBString(dobUnformatted);
    
    let verified = false;

    for (let role of roles) {
        const { classType, ssn: expectedSSN, dob: expectedDOB } = role;
        const isVerified = (classType === 'Owner' || classType === 'JointOwner') && 
                            (actualSSN === expectedSSN && actualDOB === expectedDOB);
        if (isVerified) {
            verified = true;
            break;
        }
    }

    if (!verified) throw new Error('owner unverified');
};

const calculateContractAge = (effectiveDate, currentDate) => {
    const differenceInDays = datediff(effectiveDate, currentDate);
    
    return Math.abs(Math.round((differenceInDays/365.25)));
};

const buildAllocationPrompt = (allocations, anniversaryDate) => {
    if (!allocations?.length) return null;
    
    let prompt = '<speak><prosody rate="90%">Current allocations are: ';
    allocations.forEach(allocation => {
        const { allocationsFundIndex, allocationAmount } = allocation;
        prompt += `${allocationsFundIndex}, with a value of $${allocationAmount}<break time='1s'/>`;
    });
    
    const anniversaryDateStringWithYear = buildDateString(anniversaryDate, '/');
    const anniversaryDateString = anniversaryDateStringWithYear.substring(0, anniversaryDateStringWithYear.lastIndexOf('/'));
    prompt += 'Allocation changes can be made annually up to 30 days following the contract anniversary of ' + 
                `<say-as interpret-as='date' format='md'>${anniversaryDateString}</say-as></prosody></speak>`;

    return prompt.replaceAll('&', '&amp;');
};

const buildSurrenderChargeExistsPrompt = (rate) => {
    if (!rate) return null;
    
    return `The surrender charge percentage is ${rate}%`;
};

const buildMarketValueNotZeroPrompt = (marketValue) => {
    if (!marketValue) return null;

    return `The market value adjustment is ${(marketValue > 0) ? 'positive' : 'negative'} $${Math.abs(marketValue)}`
};

const calculateContractAnniversary = (effectiveDate, currentDate) => {
    const currentYear = currentDate.getUTCFullYear();
    const currentMonth = currentDate.getUTCMonth();
    const currentDay = currentDate.getUTCDate();
    const anniversaryMonth = effectiveDate.getUTCMonth();
    const anniversaryDay = effectiveDate.getUTCDate();
    const thisYearAnniversaryPassed = (currentMonth > anniversaryMonth) || 
        ((currentMonth === anniversaryMonth) && (currentDay > anniversaryDay));

    const thisYear = new Date(Date.UTC(currentYear, anniversaryMonth, anniversaryDay));
    const lastYear = new Date(Date.UTC(currentYear - 1, anniversaryMonth, anniversaryDay));

    return (thisYearAnniversaryPassed) ? thisYear : lastYear;
};

const buildSurrenderChargeGreaterThanZeroPrompt = (surrenderCharge, surrenderYear, chargePeriods) => {
    if (!surrenderCharge || surrenderCharge < 0) return null;

    return `And the contract is in the ${surrenderYear} year of a ${chargePeriods} year surrender charge period.`
};

const buildLastFinancialTransactionPrompt = (financialActivityType, grossAmount, memoCode, activityEffectiveDate, transactionDate) => {
    const canBuild = financialActivityType && grossAmount && memoCode && activityEffectiveDate && transactionDate;
    if (!canBuild) return null;

    const effectiveDateString = buildDateString(new Date(activityEffectiveDate), '/');
    const transactionDateString = buildDateString(new Date(transactionDate), '/');
    
    let promptType;
    let useEffective = false;

    switch(financialActivityType) {
        case 'Withdrawal':
            switch(memoCode) {
                case 'Transfer':
                    promptType = 'partial transfer';
                    break;
                case '1035 Exchange':
                    promptType = 'partial exchange';
                    break;
                case 'Rollover':
                    promptType = 'partial rollover';
                    break;
                case 'Required Minimum Distribution':
                    promptType = 'required minimum distribution';
                    break;
                case 'Partial Withdrawal':
                    promptType = 'partial withdrawal';
                    break;
                default:
                    return null;
            }
            break;
        case 'Payment':
            useEffective = true;
            promptType = 'payment';
            break;
        case 'Policy Charge':
            switch(memoCode) {
                case 'Income Rider Charge':
                    promptType = 'rider charge';
                    break;
                default:
                    return null;
            }
            break;
        case 'Surrender':
            switch(memoCode) {
                case '1035 Exchange':
                    promptType = 'full exchange';
                    break;
                case 'Transfer':
                    promptType = 'full transfer';
                    break;
                case 'Rollover':
                    promptType = 'full rollover';
                    break;
                case 'Full Surrender':
                    promptType = 'full surrender distribution';
                    break;
                case 'Full Surrender, Disability':
                    promptType = 'full surrender, disability distribution';
                    break;
                case 'Full Surrender, Separation of Service':
                    promptType = 'full surrender, separation of service distribution';
                    break;
                default:
                    return null;
            }
            break;
        case 'Loan':
            switch(memoCode) {
                case 'Repayment':
                    promptType = 'loan repayment';
                    break;
                default:
                    return null;
            }
            break;
        default:
            return null;
    }

    return `The last transaction was a ${promptType} of $${grossAmount} on <say-as interpret-as='date' format='mdy'>` + 
        `${(useEffective) ? effectiveDateString : transactionDateString}</say-as>`;
};

const hydrateACC = async (tid, params) => {
    const connectResponse = new ACCResponse();

    // dob is string
    const endpoint = `/session/data/sid/${tid}`;
    
    // Get hydrated data
    let policyDomain;
    try {
        const data = await getHydratedData(endpoint);
        policyDomain = data.policyDomains[0];
    } catch(e) {
        console.error(e);
        return connectResponse;
    }
    
    console.log(policyDomain);

    // Destructure response object for processing
    const { policyNumber, policyInfo } = policyDomain;
    const { policyRoles, 
            hasPassPhrase, 
            hasPriorityNote, 
            policyRestriction, 
            policyType, 
            december31stValue, 
            currentYearRMDAmount, 
            currentYearRMDBalanceAmount, 
            valueAsOfDate, 
            surrenderValue, 
            surrenderCharge,  
            effectiveDate: policyEffectiveDateEpoch,
            marketValue,
            allocations,
            taxQualificationType,
            billing,
            surrenderChargeInfo,
            transactionActivity 
    } = policyInfo;
    const { accumulatedValue, maximumWithdrawalAmtAvailable } = billing;
    const { schedule } = surrenderChargeInfo;
    const { financialActivityType, 
            grossAmount, 
            memoCode, 
            effectiveDate: activityEffectiveDate, 
            transactionDate 
    } = transactionActivity;

    // Process minimum information needed to return if ownerVerified === false
    connectResponse.hasPassPhrase = hasPassPhrase;
    connectResponse.hasPriorityNote = hasPriorityNote;
    connectResponse.isAnnuityVariablePolicy = policyType.includes('Variable');
    connectResponse.annuityRestrictionExists = policyRestriction.code !== NO_POLICY_RESTRICTION;
    
    // Verify Owner
    try {
        verifyOwner(policyRoles, params);
        connectResponse.ownerVerified = true;
    } catch {
        connectResponse.ownerVerified = false;
        return connectResponse;
    }

    // Create calculation helper variables/objects
    const currentDateObj = new Date();
    const policyEffectiveDateObj = new Date(policyEffectiveDateEpoch);
    const policyAsOfDateObj = new Date(valueAsOfDate);
    const anniversaryDateObj = calculateContractAnniversary(policyEffectiveDateObj, currentDateObj);
    const contractAge = calculateContractAge(policyEffectiveDateObj, currentDateObj);
    
    // Process response properties needed to determine other response properties
    const surrenderScheduleYear = contractAge + 1;
    const surrenderChargePeriods = schedule.length;
    const scheduleRate = schedule?.[contractAge]?.rate || null;
    const daysBetweenContractAnniversaryDate = datediff(anniversaryDateObj, currentDateObj);
    const policyAsOfDateExists = !isNaN(policyAsOfDateObj.getTime());
    const policyAsOfDate = (policyAsOfDateExists) ? buildDateString(policyAsOfDateObj, '/') : null;

    // Build rest of response
    connectResponse.policyType = policyType;
    connectResponse.isAnnuityFixedPolicy = policyType.includes('Fixed');
    connectResponse.isAnnuityIndexedPolicy = policyType.includes('Indexed');
    connectResponse.policyEffectiveDate = policyEffectiveDateObj.toISOString();
    connectResponse.isLiveWellPolicy = (
            !policyNumber.startsWith("71") || 
            !policyNumber.startsWith("72") || 
            !policyNumber.startsWith("73") || 
            !policyNumber.startsWith("77")
        ) && policyType.includes('LiveWell');
    connectResponse.dec31stValue = december31stValue;
    connectResponse.currentYearRMDAmount = currentYearRMDAmount;
    connectResponse.currentYearRMDBalanceAmount = currentYearRMDBalanceAmount;
    connectResponse.policyAsOfDate = policyAsOfDate;
    connectResponse.policyAsOfDateExists = policyAsOfDateExists;
    connectResponse.accumulatedValue = accumulatedValue;
    connectResponse.surrenderCharge = surrenderCharge;
    connectResponse.surrenderValue = surrenderValue;
    connectResponse.surrenderScheduleYear = surrenderScheduleYear;
    connectResponse.maximumWithdrawalAmtAvailable = maximumWithdrawalAmtAvailable;
    connectResponse.marketValue = marketValue;
    connectResponse.transactionInLast365Days = datediff(activityEffectiveDate, currentDateObj) < 365;
    connectResponse.ineligibleTaxQualyTypeExists = taxQualificationType === 'Non-Qualified' || 
                                        taxQualificationType === 'Roth IRA' || 
                                        taxQualificationType === 'Roth Conversion';
    connectResponse.surrenderChargePeriods = surrenderChargePeriods;
    connectResponse.scheduleRate = scheduleRate;
    connectResponse.surrenderChargeScheduleExistsPrompt = buildSurrenderChargeExistsPrompt(scheduleRate);
    connectResponse.allocationsPrompt = buildAllocationPrompt(allocations, anniversaryDateObj);
    connectResponse.marketValueNotZeroPrompt = buildMarketValueNotZeroPrompt(marketValue);
    connectResponse.daysBetweenContractAnniversaryDate = daysBetweenContractAnniversaryDate;
    connectResponse.contractAnniversaryLessThan30Days = daysBetweenContractAnniversaryDate < 30;
    connectResponse.surrenderChargeGreaterThanZeroPrompt = buildSurrenderChargeGreaterThanZeroPrompt(surrenderCharge, surrenderScheduleYear, surrenderChargePeriods);
    connectResponse.lastFinancialTransactionPrompt = buildLastFinancialTransactionPrompt(financialActivityType, grossAmount, memoCode, activityEffectiveDate, transactionDate);

    return connectResponse;
};

export default hydrateACC;