class LCCResponse {
    ownerVerified;
    policyType;
    policyEffectiveDate;
    hasPassPhrase;
    hasPriorityNote;
    annuityRestrictionExists;
    dec31stValue;
    currentYearRMDAmount;
    currentYearRMDBalanceAmount;
    policyAsOfDate;
    policyAsOfDateExists;
    accumulatedValue;

    maximumWithdrawalAmtAvailable;
    marketValue;
    transactionInLast365Days;
    ineligibleTaxQualyTypeExists;
    scheduleRate;
    surrenderChargeScheduleExistsPrompt;
    daysBetweenContractAnniversaryDate;
    contractAnniversaryLessThan30Days;
    
    lastFinancialTransactionType;
    lastFinancialTransactionDate;
    lastFinancialTranactionAmount;
    lineOfBusiness;
    policyRestrictionReason;
    policyBillingType;
    deathClaimPending;
    outstandingLoanBalanceAmount;
    lastFinancialTransactionEffectiveDate;
    deathBenefitAmount;
    billingPaidToDate;
    billingFrequency;
    billToDate;
    lastPremiumAmount;
    lastPaymentDate;
    policyPremiumAmount;
    isProductTypeUIL;
    hasOutstandingLoanBalance;
    isDeathClaimRelated;
    shouldRouteToQueue;
    graceAmount;
    graceExpiryDate;
    isVariablePolicy;
    isTermPolicy;
    isPolicyRestricted
    
    surrenderValue;
    surrenderCharge;
    surrenderChargePeriods;
    
    surrenderChargeGreaterThanZeroPrompt;
    surrenderChargeScheduleExistsPrompt;
    surrenderScheduleYear;
    
    marketValueNotZeroPrompt
    lastFinancialTransactionPrompt;
    outstandingLoanBalancePrompt;
    allocationsPromptLCC;
    policyInformationPrompt;
    billingInformationPrompt;
    
    
    constructor() {
        for (const prop of Object.getOwnPropertyNames(this)) {
            this[prop] = null;
        }
    }
}
export default LCCResponse;