import https from 'node:https';
import ACCResponse from './classes/ACCResponse.mjs';
import LCCResponse from './classes/LCCResponse.mjs';

const ODS_API_BASE_URL = process.env.ODS_API_BASE_URL; 
const ODS_API_USERNAME = process.env.ODS_API_USERNAME;
const ODS_API_PASSWORD = process.env.ODS_API_PASSWORD;
const AUTHORIZATION = `Basic ${Buffer.from(`${ODS_API_USERNAME}:${ODS_API_PASSWORD}`).toString('base64')}`;
const REQUEST_OPTIONS = {
    method: 'GET',
    headers: {
        'Authorization': AUTHORIZATION,
        'Content-Type': 'application/json'
    }
};

const getHydratedData = async (endpoint) => {
    const url = ODS_API_BASE_URL + endpoint;
    const result = await sendHttpsRequest(url);
    const parsedResult = JSON.parse(result);

    if (parsedResult.errorDetails) throw new Error('server error');

    return parsedResult;
};

const sendHttpsRequest = (url) => new Promise((resolve, reject) => {
    const cb = (res) => {
        if (res.statusCode < 200 || res.statusCode > 299) {
            reject(new Error());
            return;
        }

        let data = '';

        res.on('data', (chunk) => data += chunk);
        res.on('end', () => resolve(data));
    };

    const req = https.request(url, REQUEST_OPTIONS, cb);
    req.on('error', (err) => reject(err));
    req.end();
});

const formatISODOBString = (unformattedDOBString) => {
    const parts = unformattedDOBString.split('-');
    const epoch = Date.UTC(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    
    return buildDateString(new Date(epoch));
};

const buildDateString = (date, delimiter='') => {
    const mm = date.getUTCMonth() + 1;
    const monthPrefix = (mm < 10) ? '0' : '';
    const dd = date.getUTCDate();
    const datePrefix = (dd < 10) ? '0' : '';
    const yyyy = date.getUTCFullYear();
    
    return monthPrefix + mm + delimiter + datePrefix + dd + delimiter + yyyy;
};

const datediff = (startDate, endDate) => Math.round(((endDate - startDate) / (24 * 60 * 60 * 1000)));

export {
    ACCResponse,
    LCCResponse,
    getHydratedData,
    formatISODOBString,
    buildDateString,
    datediff
};