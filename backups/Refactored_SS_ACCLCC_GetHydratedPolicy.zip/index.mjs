/****************************************************************
The purpose of this Lambda is to retrieve ALL policy 
related information including  details by calling the 
core services API with the transaction id as input parameter
and then pass the required data back to the contact flow as
individual parameters so it follows contact flows best practices.

input: input_ownerSSN, input_ownerDOB, input_lineOfBusiness
output: policy details (many outputs)

Created By  - VH, EP
Release     - Version 3
Date        - 9/12/23
****************************************************************/

import hydrateACC from './ACC/acc-owner-logic.mjs';
import hydrateLCC from './LCC/lcc-owner-logic.mjs';

const ANNUITY = 'Annuity';
const LIFE = 'Life';

const stringifyBooleans = (obj) => {
    for (const [k,v] of Object.entries(obj)) {
        if (typeof v !== 'boolean') continue;
        obj[k] = v.toString();
    }

    return obj;
};

export const handler = async (event) => {
    const { Details: { Parameters: { input_transactionId: transactionId, input_lineOfBusiness: lineOfBusiness, ...params } = {} } = {} } = event;
    const baseResponse = { transactionId, ownerVerified: false };
    
    let lineOfBusinessResponse = null;

    switch(lineOfBusiness) {
        case ANNUITY:
            lineOfBusinessResponse = await hydrateACC(transactionId, params);
            break;
        case LIFE:
            lineOfBusinessResponse = await hydrateLCC(transactionId, params);
            break;
        default:
            // should never run
    }

    return stringifyBooleans({ ...baseResponse, ...lineOfBusinessResponse });
};