import { LCCResponse,
        getHydratedData, 
        formatISODOBString, 
        buildDateString,
        datediff
} from '../utils/hydration-helper.mjs';

const NO_POLICY_RESTRICTION = '1013700000';

// MOVE TO UTILS
const verifyOwner = (roles, { input_ownerDOB: dobUnformatted, input_ownerSSN: actualSSN }) => {
    // YYYY-MM-DD to MMDDYYYY
    const actualDOB = formatISODOBString(dobUnformatted);
    
    let verified = false;

    for (let role of roles) {
        const { classType, ssn: expectedSSN, dob: expectedDOB } = role;
        const isVerified = (classType === 'Owner' || classType === 'JointOwner') && 
                            (actualSSN === expectedSSN && actualDOB === expectedDOB);
        if (isVerified) {
            verified = true;
            break;
        }
    }

    if (!verified) throw new Error('owner unverified');
};

// COMPUTATIONS

const calculateContractAge = (effectiveDate, currentDate) => {
    const differenceInDays = datediff(effectiveDate, currentDate);
    
    return Math.abs(Math.round((differenceInDays/365.25)));
};

const calculateContractAnniversary = (effectiveDate, currentDate) => {
    const currentYear = currentDate.getUTCFullYear();
    const currentMonth = currentDate.getUTCMonth();
    const currentDay = currentDate.getUTCDate();
    const anniversaryMonth = effectiveDate.getUTCMonth();
    const anniversaryDay = effectiveDate.getUTCDate();
    const thisYearAnniversaryPassed = (currentMonth > anniversaryMonth) || 
        ((currentMonth === anniversaryMonth) && (currentDay > anniversaryDay));

    const thisYear = new Date(Date.UTC(currentYear, anniversaryMonth, anniversaryDay));
    const lastYear = new Date(Date.UTC(currentYear - 1, anniversaryMonth, anniversaryDay));

    return (thisYearAnniversaryPassed) ? thisYear : lastYear;
};

const buildAllocationsPromptLCC = (allocations) => {
    if(!allocations?.length) return null;
    
    let prompt = '<speak><prosody rate="90%">Current allocations are: ';
    allocations.forEach(allocation => {
        const { allocationsPercentValue, allocationsFundIndex, allocationAmount } = allocation;
        const percentValue = Math.round(allocationsPercentValue * 100);
        prompt += `${percentValue}% ${allocationsFundIndex}, with a value of $${allocationAmount}<break time='1s'/>`;
    });
    
    prompt += "Values are as of previous business day.</prosody></speak> "
    
    let promptStr = prompt.replace(/&/g, '&amp;')
    
    return promptStr;
}

// PROMPTS
const buildSurrenderChargeExistsPrompt = (rate) => {
    if (!rate) return null;
    
    return `The surrender charge percentage is ${rate}%`;
};

const buildMarketValueNotZeroPrompt = (marketValue) => {
    if (!marketValue) return null;

    return `The market value adjustment is ${(marketValue > 0) ? 'positive' : 'negative'} $${Math.abs(marketValue)}`
};



// const buildSurrenderChargeGreaterThanZeroPrompt = (surrenderCharge, surrenderYear, chargePeriods) => {
//     if (!surrenderCharge || surrenderCharge < 0) return null;

//     return `And the contract is in the ${surrenderYear} year of a ${chargePeriods} year surrender charge period.`
// };

const buildLastFinancialTransactionPrompt = (financialActivityType, grossAmount, memoCode, activityEffectiveDate, transactionDate) => {
    const canBuild = financialActivityType && grossAmount && memoCode && activityEffectiveDate && transactionDate;
    if (!canBuild) return null;

    const effectiveDateString = buildDateString(new Date(activityEffectiveDate), '/');
    const transactionDateString = buildDateString(new Date(transactionDate), '/');
    
    let promptType;
    let useEffective = false;

    switch(financialActivityType) {
        case 'Payment':
            useEffective = true;
            promptType = 'premium payment';
            break;
        
        case 'Loan':
            switch(memoCode) {
                case 'Repayment':
                    promptType = 'loan payment';
                    useEffective = true;
                    break;
                case 'Loan Interest':
                    promptType = 'loan interest charge';
                    useEffective = true;
                    break;
                case 'Origination':
                    promptType = 'full transfer';
                    break;
                default:
                    return null;
            }
            break;
        
        case 'Loan':

        default:
            return null;
    }

    return `<speak>The last transaction was a ${promptType} of $${grossAmount} on <say-as interpret-as='date' format='mdy'>` + 
        `${(useEffective) ? effectiveDateString : transactionDateString}</say-as></speak> `;
        
};

const buildPolicyInformationPrompt = (isGraceStatus, graceAmount, graceExpiryDate, policyType, deathBenefitAmount, surrenderValue, valueAsOfDate) => {

    let message = "<speak> ";

    // Check if policy in 'Grace' status
    if (isGraceStatus) {
        message += `This policy is in grace for $${graceAmount}. If a payment is not received by ${graceExpiryDate}, this policy will lapse. To make a payment please visit our website.`;
    }

    // Display the policy type and death benefit
    message += ` This is a ${policyType} policy for $${deathBenefitAmount}.`;

    // Check if there's a surrender value
    if (surrenderValue > 0) {
        message += `The net cash value for this policy as of <say-as interpret-as='date' format='mdy'> ${valueAsOfDate} </say-as> is $${surrenderValue}.`;

        // Check if policy is of a certain type and has a surrender value
        const policyTypesForLoan = ['Whole Life', 'Interest Sensitive Whole Life', 'Mizer'];
        if (policyTypesForLoan.includes(policyType)) {
            message += "A portion of this value may be available for loan.";
        }

        // Check if policy is another certain type
        const policyTypesForLoanOrWithdrawal = ['Universal Life', 'Indexed Universal Life', 'Variable Universal Life'];
        if (policyTypesForLoanOrWithdrawal.includes(policyType)) {
            message += "A portion of this value may be available for loan or withdrawal.";
        }
    }

    // End the message
    message += "That's all the policy information I have. </speak> ";

    return message;
};

const buildBillingInformationPrompt = (policyStatus, graceAmount, graceExpiryDate, billingPaidToDate, billingFormOfPayment, billingFrequency, policyPremiumAmount, billToDate, policyType, lastPremiumAmount, lastPaymentDate) => {
    console.log("BUILDBILLINGINFORMATION", {
        "billingFormOfPayment": billingFormOfPayment
    })
    let message = "<speak>";
    
    // Check if policy in 'Grace' status
    if (policyStatus === "Grace") {
        message += `This policy is in grace for $${graceAmount}. If a payment is not received by ${graceExpiryDate}, this policy will lapse. To make a payment please visit our website.`;
    } else if (policyStatus === "Paid Up" || "Reduced Paid Up"){
        message += `This is a paid up policy effective ${billingPaidToDate}.`;
    } else if (billingFormOfPayment === "No Billing" || "Supressed Billing") {
        message += `This policy is on a No Bill status.`;
    } else {
        message += `The ${billingFrequency} ${billingFormOfPayment} is $${policyPremiumAmount}.`;
    
        if (policyStatus === "Extended Term Insurance") {
            message += ` This policy has been converted to extended term insurance effective ${billToDate}.`;
        } 
        else {
            let dateDisplay = (policyType === "Indexed Universal Life") ? billToDate : billingPaidToDate;
            message += `The last payment of $${lastPremiumAmount} was received on ${lastPaymentDate}. Your next schedule premium payment of $${policyPremiumAmount} is due on ${dateDisplay}.`;
        }
    }
    
    message += " That is all of the billing information I have for this policy.</speak>";
    
    return message;
};


const hydrateLCC = async (tid, params) => {
    const connectResponse = new LCCResponse();

    // dob is string
    const endpoint = `/session/data/sid/${tid}`;
    
    // Get hydrated data
    let policyDomain;
    try {
        const data = await getHydratedData(endpoint);
        console.log(data);
        policyDomain = data.policyDomains[0];
    } catch(e) {
        console.error(e);
        return connectResponse;
    }

    // Destructure response object for processing
    const { policyNumber, policyInfo } = policyDomain;
    const { policyRoles, 
            hasPassPhrase,
            hasPriorityNote, 
            policyRestriction, 
            policyType,
            policyStatus,
            productType,
            december31stValue, 
            currentYearRMDAmount, 
            currentYearRMDBalanceAmount, 
            valueAsOfDate, 
            surrenderValue, 
            surrenderCharge,  
            effectiveDate: policyEffectiveDateEpoch,
            marketValue,
            allocations,
            taxQualificationType,
            billing,
            transactionActivity,
            outstandingLoanBalanceAmount,
            deathBenefitAmount,
            graceAmount,
            graceExpiryDate,
            //surrenderChargeInfo
    } = policyInfo;
    const { accumulatedValue, maximumWithdrawalAmtAvailable } = billing;
    const { financialActivityType, 
            grossAmount, 
            memoCode, 
            effectiveDate: activityEffectiveDate, 
            transactionDate 
    } = transactionActivity;
    
    // Create calculation helper variables/objects
    const currentDateObj = new Date();
    const policyEffectiveDateObj = new Date(policyEffectiveDateEpoch);
    const policyAsOfDateObj = new Date(valueAsOfDate);
    const anniversaryDateObj = calculateContractAnniversary(policyEffectiveDateObj, currentDateObj);
    const contractAge = calculateContractAge(policyEffectiveDateObj, currentDateObj);
    //const scheduleRate = surrenderChargeInfo?.[contractAge]?.rate || null;
    
    
    // Process response properties needed to determine other response properties
    //const surrenderScheduleYear = contractAge + 1;

    const daysBetweenContractAnniversaryDate = datediff(anniversaryDateObj, currentDateObj);
    const policyAsOfDateExists = !isNaN(policyAsOfDateObj.getTime());
    const policyAsOfDate = (policyAsOfDateExists) ? buildDateString(policyAsOfDateObj, '/') : null;

    const buildOutstandingLoanBalancePrompt = () => {
    return `<speak>Effective as of the last business day, the outstanding loan balance is ${outstandingLoanBalanceAmount}. This amount, may or may not include any accrued interest since the Policy anniversary. This is not a Payoff amount.</speak> `;
    };

    

    const deathClaimStatuses = ["21", "22"];
    const statusesNoRoutingToQueueNeeded = ["1", "3", "26", "27", "25", "31", "23"];
    const isGraceStatus = policyStatus.statusCode === "26";
    const billingPaidToDate = billing.paidToDate;
    const billingFormOfPayment = billing.formOfPayment;
    const billingFrequency = billing.scheduledFrequency;
    const policyPremiumAmount = billing.policyPremiumAmount;
    const billToDate = billing.billToDate;
    const lastPremiumAmount = policyInfo.financialActivitySummary?.lastPremiumAmount;
    const lastPremiumPaidDate = policyInfo.financialActivitySummary?.lastPremiumPaidDate;
    // const surrenderChargePeriods = schedule.length;
    
    // Verify Owner
    try {
        verifyOwner(policyRoles, params);
        connectResponse.ownerVerified = true;
    } catch {
        connectResponse.ownerVerified = false;
        return connectResponse;
    }

    // Process minimum information needed to return if ownerVerified === false
    connectResponse.hasPassPhrase = hasPassPhrase;
    connectResponse.hasPriorityNote = hasPriorityNote;
    connectResponse.isVariablePolicy = policyType.includes('Variable');
    connectResponse.isTermPolicy = policyType.includes('Term');
    
    // Build rest of response
    connectResponse.policyType = policyType;
    connectResponse.policyEffectiveDate = policyEffectiveDateObj.toISOString();
    connectResponse.dec31stValue = december31stValue;
    connectResponse.currentYearRMDAmount = currentYearRMDAmount;
    connectResponse.currentYearRMDBalanceAmount = currentYearRMDBalanceAmount;
    connectResponse.policyAsOfDate = policyAsOfDate;
    connectResponse.policyAsOfDateExists = policyAsOfDateExists;
    connectResponse.accumulatedValue = accumulatedValue;
    connectResponse.maximumWithdrawalAmtAvailable = maximumWithdrawalAmtAvailable;
    connectResponse.marketValue = marketValue;
    connectResponse.transactionInLast365Days = datediff(activityEffectiveDate, currentDateObj) < 365;
    connectResponse.ineligibleTaxQualyTypeExists = taxQualificationType === 'Non-Qualified' || 
                                        taxQualificationType === 'Roth IRA' || 
                                        taxQualificationType === 'Roth Conversion';
   
    connectResponse.daysBetweenContractAnniversaryDate = daysBetweenContractAnniversaryDate;
    connectResponse.contractAnniversaryLessThan30Days = daysBetweenContractAnniversaryDate < 30;
    connectResponse.lastFinancialTransactionType = financialActivityType;
    connectResponse.lastFinancialTransactionDate = buildDateString(new Date(transactionDate), '/');
    connectResponse.lastFinancialTranactionAmount = grossAmount;
    connectResponse.lineOfBusiness = productType;
    connectResponse.policyBillingType = billing.formOfPayment;
    connectResponse.isPolicyRestricted = policyRestriction.code !== NO_POLICY_RESTRICTION;
    
    
    connectResponse.isDeathClaimRelated = deathClaimStatuses.includes(policyStatus.statusCode);
    connectResponse.shouldRouteToQueue = !statusesNoRoutingToQueueNeeded.includes(policyStatus.statusCode); 
    
    connectResponse.outstandingLoanBalanceAmount = outstandingLoanBalanceAmount;
    connectResponse.lastFinancialTransactionEffectiveDate = policyEffectiveDateEpoch;
    connectResponse.deathBenefitAmount = deathBenefitAmount;
    connectResponse.billingPaidToDate = billing.paidToDate;
    connectResponse.billingFormOfPayment = billing.formOfPayment;
    connectResponse.billingFrequency = billing.scheduledFrequency;
    connectResponse.billToDate = billing.billToDate;
    connectResponse.lastPremiumAmount = lastPremiumAmount;
    connectResponse.lastPaymentDate = lastPremiumPaidDate;
    connectResponse.policyPremiumAmount = billing.policyPremiumAmount;
    
    
    connectResponse.isProductTypeUIL = policyType == "Indexed Universal Life";
    connectResponse.hasOutstandingLoanBalance = outstandingLoanBalanceAmount > 0;

    connectResponse.isGraceStatus = isGraceStatus;
    connectResponse.graceAmount = graceAmount;
    connectResponse.graceExpiryDate = graceExpiryDate;
    
    // connectResponse.surrenderChargeScheduleTotal = surrenderChargeInfo.schedule.length;
    // surrender related
    connectResponse.surrenderValue = surrenderValue; // policyInfo property -- OK
    connectResponse.surrenderCharge = surrenderCharge; // policyInfo property -- OK
    //connectResponse.surrenderChargePeriods = surrenderChargeInfo?.schedule?.length; // do it through a function
    
    
    // connectResponse.surrenderScheduleYear = surrenderScheduleYear;
    
    //connectResponse.surrenderChargeScheduleExistsPrompt = buildSurrenderChargeExistsPrompt(scheduleRate);
    
    // Prompts
    
    connectResponse.marketValueNotZeroPrompt = buildMarketValueNotZeroPrompt(marketValue);
    connectResponse.lastFinancialTransactionPrompt = buildLastFinancialTransactionPrompt(financialActivityType, grossAmount, memoCode, activityEffectiveDate, transactionDate);
    connectResponse.outstandingLoanBalancePrompt = buildOutstandingLoanBalancePrompt();
    connectResponse.allocationsPromptLCC = buildAllocationsPromptLCC(allocations);
    connectResponse.policyInformationPrompt = buildPolicyInformationPrompt(isGraceStatus, graceAmount, graceExpiryDate, policyType, deathBenefitAmount, surrenderValue, valueAsOfDate);
    connectResponse.billingInformationPrompt = buildBillingInformationPrompt(policyStatus, graceAmount, graceExpiryDate, billingPaidToDate, billingFormOfPayment, billingFrequency, policyPremiumAmount, billToDate, policyType, lastPremiumAmount, lastPremiumPaidDate);
    
    return connectResponse;
};

export default hydrateLCC;