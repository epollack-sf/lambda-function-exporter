/****************************************************************
The purpose of this Lambda is to setup an agent that has been verified
by using SSN (or DOB) and existing transaction id to weed out agentdomain
array items that do not match SSN (or DOB) and pass that response in an API
call.

input: SSN, DOB, Transaction id 
output: transactionId, setupSuccessful (if any errors occur, false)


Created By  - VH, EP
Release     - Version 3
Date        - 9/22/2023
****************************************************************/

import https from 'node:https';
import AgentStrategy from './strategies/agent/AgentStrategy.mjs';
import AdvisorStrategy from './strategies/advisor/AdvisorStrategy.mjs';

const ODS_API_BASE_URL = process.env.ODS_API_BASE_URL; 
const ODS_API_USERNAME = process.env.ODS_API_USERNAME;
const ODS_API_PASSWORD = process.env.ODS_API_PASSWORD;
const AUTHORIZATION = `Basic ${Buffer.from(`${ODS_API_USERNAME}:${ODS_API_PASSWORD}`).toString('base64')}`;
const CONTENT_TYPE = 'application/json';
const STRATEGIES = {
    Agent: AgentStrategy,
    Advisor: AdvisorStrategy
};

let strategy;

// No errorDetails property in response, no need to check
const updateDetails = async (endpoint, data) => {
    await sendHttpsRequest('PUT', endpoint, data);
}

// Filters based on ssn and dob
const filterDomains = (domains) => {
    const filteredDomains = strategy.filterDomains(domains);

    if (!filteredDomains.length) throw new Error('no domains');

    return filteredDomains;
};

const getDetails = async (endpoint) => {
    const result = await sendHttpsRequest('GET', endpoint);

    return JSON.parse(result);
};

const sendHttpsRequest = (method, url, data=null) => new Promise((resolve, reject) => {
    const dataString = (data) ? JSON.stringify(data) : null;
    const contentLength = dataString?.length || 0;
    const options = {
        method: method,
        headers: {
            'Authorization': AUTHORIZATION,
            'Content-Type': CONTENT_TYPE,
            'Content-Length': contentLength
        }
    };
    const cb = (res) => {
        if (res.statusCode < 200 || res.statusCode > 299) {
            reject(new Error('bad response'));
            return;
        }

        let data = '';

        res.on('data', (chunk) => data += chunk);
        res.on('end', () => resolve(data));
    };

    const req = https.request(url, options, cb);
    req.on('error', (err) => reject(err));
    
    if (data) req.write(dataString);
    req.end();
});

const stringifyBooleans = (obj) => {
    for (const [k,v] of Object.entries(obj)) {
        if (typeof v !== 'boolean') continue;
        obj[k] = v.toString();
    }

    return obj;
};

export const handler = async (event) => {
    // Parse event
    const { Details: { Parameters: params } = {} } = event;
    const { input_transactionId: transactionId, input_ssn: ssn, input_dob: dob, input_caller: caller } = params;

    // Instantiate and parse strategy
    strategy = new STRATEGIES[caller](transactionId, caller, ssn, dob);
    const { retrievalEndpoint, updateEndpoint, domainProperty } = strategy;

    // Build endpoints
    const detailRetrievalUrl = ODS_API_BASE_URL + retrievalEndpoint;
    const detailUpdateUrl = ODS_API_BASE_URL + updateEndpoint;

    let setupSuccessful = true;

    // Get, filter, and update domains
    try {
        const details = await getDetails(detailRetrievalUrl);
        const domains = details[domainProperty];
        const initialNumberOfDomains = domains.length;
        const filteredDomains = filterDomains(domains);

        if (!filteredDomains.length < initialNumberOfDomains) {
            return stringifyBooleans({ transactionId, setupSuccessful });
        }

        details[domainProperty] = filteredDomains;
        await updateDetails(detailUpdateUrl, details);
    } catch(e) {
        console.error(e);
        setupSuccessful = false;
    }
    
    return stringifyBooleans({ transactionId, setupSuccessful });
};