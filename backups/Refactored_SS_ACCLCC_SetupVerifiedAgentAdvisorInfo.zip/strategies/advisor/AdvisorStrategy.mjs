import SSNDOBVerificationStrategy from '../SSNDOBVerificationStrategy.mjs';

const UPDATE_ENDPOINT = '/advisor/active/advisors';
const DOMAIN_PROPERTY = 'advisorDomains';

class AdvisorStrategy extends SSNDOBVerificationStrategy{
    constructor(tid, caller, ssn, dob) {
        super(tid, caller, ssn, dob, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }
}

export default AdvisorStrategy;