import SSNDOBVerificationStrategy from '../SSNDOBVerificationStrategy.mjs';

const UPDATE_ENDPOINT = '/agent/producers';
const DOMAIN_PROPERTY = 'agentDomains';

class AgentStrategy extends SSNDOBVerificationStrategy {
    constructor(tid, caller, ssn, dob) {
        super(tid, caller, ssn, dob, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }
}

export default AgentStrategy;