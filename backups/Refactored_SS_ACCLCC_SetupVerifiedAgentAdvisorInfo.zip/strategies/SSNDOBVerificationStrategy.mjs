class SSNDOBVerificationStrategy {
    transactionId;
    caller;
    ssn;
    dob; // YYYY-MM-DD
    updateEndpoint;
    domainProperty;

    // DOB may not be included as a property in initial event
    get dobEpoch() {
        const parts = this.dob?.split('-');
        
        return Date.UTC(Number(parts?.[0]), Number(parts?.[1]) - 1, Number(parts?.[2]));
    }

    get retrievalEndpoint() {
        return `/${this.caller.toLowerCase()}/transaction/${this.transactionId}`;
    }

    constructor(tid, caller, ssn, dob, updateEndpoint, domainProperty) {
        this.transactionId = tid;
        this.caller = caller;
        this.ssn = ssn;
        this.dob = dob;
        this.updateEndpoint = updateEndpoint;
        this.domainProperty = domainProperty;
    }

    filterDomains(domains) {
        const actualDOB = this.dobEpoch;
        
        return domains.filter(domain => {
            const { authData } = domain;
            const { govtID, dob: expectedDOB } = authData;
    
            return govtID === this.ssn || actualDOB === expectedDOB;
        });
    }
}

export default SSNDOBVerificationStrategy;