/****************************************************************
The purpose of this Lambda is to call the core services API to 
validate whether an agent/advisor exists by verifying:
1. Agent/Advisor information pulled up is for the correct line of business
   and Agent/Advisor is active.
2. Filter out the unnecessary lines of businessess and send the
   entire response back to another API (post method with the transaction)

This will ultimately result in storing the ONLY the required agent/advisor 
information you need in the session which can then be called later
AFTER agent/advisor provides SSN/DOB which then can be verified

input: id, caller, line of business
output: exists, transactionId , isBusinessType


Created By  - VH, EP
Release     - Version 3
Date        - 9/21/2023
 * 
 * ERROR HANDLING can be done better, right now i'm returning 
 * promise but if call 1 or call 2 fails - we don't want the last
 * promise to return false values, we want it to flag it as error
****************************************************************/

import https from 'node:https';
import AgentStrategy from './strategies/agent/AgentStrategy.mjs';
import AdvisorStrategy from './strategies/advisor/AdvisorStrategy.mjs';

const ODS_API_BASE_URL = process.env.ODS_API_BASE_URL; 
const ODS_API_USERNAME = process.env.ODS_API_USERNAME;
const ODS_API_PASSWORD = process.env.ODS_API_PASSWORD;
const AUTHORIZATION = `Basic ${Buffer.from(`${ODS_API_USERNAME}:${ODS_API_PASSWORD}`).toString('base64')}`;
const CONTENT_TYPE = 'application/json';
const ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const ID_LENGTH = 32;
const PERSON = 'Person';
const STRATEGIES = {
    Agent: AgentStrategy,
    Advisor: AdvisorStrategy
};

let strategy;

const generateTransactionId = () => {
    let rtn = '';
    for (let i=0; i<ID_LENGTH; i++) {
        rtn += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
    }

    return `AC${rtn}`;
};

// No errorDetails property in response, no need to check
const updateDetails = async (endpoint, data) => {
    await sendHttpsRequest('POST', endpoint, data);
};

const getBusinessType = (domains) => {
    return !domains.some(domain => {
        const { authData } = domain;
        const { classType } = authData;

        return classType === PERSON;
    });
};

const filterDomains = (domains) => {
    const filteredDomains = strategy.filterDomains(domains);

    if (!filteredDomains.length) throw new Error('no domains');

    return filteredDomains;
}

// No errorDetails property in response, no need to check
const getDetails = async (endpoint) => {
    const result = await sendHttpsRequest('GET', endpoint);
    
    return JSON.parse(result);
}

const sendHttpsRequest = (method, url, data=null) => new Promise((resolve, reject) => {
    const dataString = (data) ? JSON.stringify(data) : null;
    const contentLength = dataString?.length || 0;
    const options = {
        method: method,
        headers: {
            'Authorization': AUTHORIZATION,
            'Content-Type': CONTENT_TYPE,
            'Content-Length': contentLength
        }
    };
    const cb = (res) => {
        if (res.statusCode < 200 || res.statusCode > 299) {
            reject(new Error('bad response'));
            return;
        }

        let data = '';

        res.on('data', (chunk) => data += chunk);
        res.on('end', () => resolve(data));
    };

    const req = https.request(url, options, cb);
    req.on('error', (err) => reject(err));
    
    if (data) req.write(dataString);
    req.end();
});

const stringifyBooleans = (obj) => {
    for (const [k,v] of Object.entries(obj)) {
        if (typeof v !== 'boolean') continue;
        obj[k] = v.toString();
    }

    return obj;
};

export const handler = async (event) => {
    // Parse event
    const { Details: { Parameters: params } = {} } = event;
    const { input_lineOfBusiness: lineOfBusiness, input_id: id, input_caller: caller } = params;
    
    // Generate transactionId
    const transactionId = generateTransactionId();

    // Instantiate and parse strategy
    strategy = new STRATEGIES[caller](transactionId, id, lineOfBusiness);
    const { retrievalEndpoint, updateEndpoint, domainProperty } = strategy;
    
    // Build endpoints
    const detailRetrievalUrl = ODS_API_BASE_URL + retrievalEndpoint;
    const detailUpdateUrl = ODS_API_BASE_URL + updateEndpoint;

    let isBusinessType = null;
    let exists = true;

    // Get, filter, and upload domains
    try {
        const details = await getDetails(detailRetrievalUrl);
        const domains = details[domainProperty];
        
        console.log(domains);
        
        
        const filteredDomains = filterDomains(domains);
        isBusinessType = getBusinessType(filteredDomains);

        details[domainProperty] = filteredDomains;
        await updateDetails(detailUpdateUrl, details);
    } catch(e) {
        console.error(e);
        exists = false;
    }

    return stringifyBooleans({ transactionId, exists, isBusinessType });
};