class IdVerificationStrategy {
    transactionId;
    id;
    lineOfBusiness;
    updateEndpoint;
    domainProperty;

    constructor(tid, id, lineOfBusiness, endpoint, property) {
        this.transactionId = tid;
        this.id = id;
        this.lineOfBusiness = lineOfBusiness;
        this.updateEndpoint = endpoint;
        this.domainProperty = property;
    }
}
export default IdVerificationStrategy;