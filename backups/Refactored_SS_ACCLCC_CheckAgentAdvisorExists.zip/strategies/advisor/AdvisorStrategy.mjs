import IdVerificationStrategy from '../IdVerificationStrategy.mjs';

const UPDATE_ENDPOINT = '/advisor/active/advisors';
const DOMAIN_PROPERTY = 'advisorDomains';

class AdvisorStrategy extends IdVerificationStrategy {
    get retrievalEndpoint() {
        return `/advisor/all/advisors/crd/${this.id}/transaction/${this.transactionId}`;
    }

    constructor(tid, id, lineOfBusiness) {
        super(tid, id, lineOfBusiness, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }

    // No filter logic for checking if an advisor exists based on CRD
    filterDomains(domains) {
        return domains;
    }
}

export default AdvisorStrategy;