import IdVerificationStrategy from '../IdVerificationStrategy.mjs';

const ACTIVE = 'Active';
const UPDATE_ENDPOINT = '/agent/producers';
const DOMAIN_PROPERTY = 'agentDomains';

class AgentStrategy extends IdVerificationStrategy {
    get retrievalEndpoint() {
        return `/agent/all/producers/agent/${this.id}/transaction/${this.transactionId}/any`;
    }

    constructor(tid, id, lineOfBusiness) {
        super(tid, id, lineOfBusiness, UPDATE_ENDPOINT, DOMAIN_PROPERTY);
    }

    filterDomains(domains) {
        return domains.filter(domain => {
            const { authData } = domain;
            const { lineOfBusiness, status } = authData;
            const { description: lobDescription } = lineOfBusiness;
            const { description: statusDescription } = status;
    
            return lobDescription === this.lineOfBusiness && statusDescription === ACTIVE;
        });
    }
}

export default AgentStrategy;