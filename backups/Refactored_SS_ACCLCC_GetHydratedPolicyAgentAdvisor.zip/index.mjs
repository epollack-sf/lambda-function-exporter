import hydrateACC from './ACC/acc-agent-logic.mjs';
import hydrateLCC from './LCC/lcc-agent-logic.mjs';

const ANNUITY = 'Annuity';
const LIFE = 'Life';

const stringifyBooleans = (obj) => {
    for (const [k,v] of Object.entries(obj)) {
        if (typeof v !== 'boolean') continue;
        obj[k] = v.toString();
    }

    return obj;
};

export const handler = async (event) => {
    const { Details: { Parameters: { input_transactionId: transactionId, input_lineOfBusiness: lineOfBusiness } = {} } = {} } = event;

    let lineOfBusinessResponse = null;

    switch(lineOfBusiness) {
        case ANNUITY:
            lineOfBusinessResponse = await hydrateACC(transactionId);
            break;
        case LIFE:
            // TODO
            lineOfBusinessResponse = await hydrateLCC(transactionId);
            break;
        default:
            // should never run
    }

    return stringifyBooleans({ transactionId , ...lineOfBusinessResponse });
};