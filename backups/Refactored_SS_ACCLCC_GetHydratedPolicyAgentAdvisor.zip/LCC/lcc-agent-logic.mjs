const hydrateLCC = async (tid) => {
    // TODO
};

export default hydrateLCC;