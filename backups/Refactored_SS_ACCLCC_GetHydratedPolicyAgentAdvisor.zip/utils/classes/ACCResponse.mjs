class ACCResponse {
    policyType;
    isAnnuityVariablePolicy;
    isAnnuityFixedPolicy;
    isAnnuityIndexedPolicy;
    policyEffectiveDate;
    hasPassPhrase;
    hasPriorityNote;
    annuityRestrictionExists;
    isLiveWellPolicy;
    dec31stValue;
    currentYearRMDAmount;
    currentYearRMDBalanceAmount;
    policyAsOfDate;
    policyAsOfDateExists;
    accumulatedValue;
    surrenderCharge;
    surrenderValue;
    surrenderScheduleYear;
    maximumWithdrawalAmtAvailable;
    marketValue;
    transactionInLast365Days;
    ineligibleTaxQualyTypeExists;
    surrenderChargePeriods;
    scheduleRate;
    surrenderChargeScheduleExistsPrompt;
    allocationsPrompt;
    marketValueNotZeroPrompt;
    daysBetweenContractAnniversaryDate;
    contractAnniversaryLessThan30Days;
    surrenderChargeGreaterThanZeroPrompt;
    lastFinancialTransactionPrompt;

    constructor() {
        for (const prop of Object.getOwnPropertyNames(this)) {
            this[prop] = null;
        }
    }
}

export default ACCResponse;