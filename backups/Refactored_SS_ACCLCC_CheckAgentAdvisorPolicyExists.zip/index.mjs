/****************************************************************
The purpose of this Lambda is to check if policy # entered by the
agent is valid and can be accessed by the agent and this returns
minimum information. Once that is done, this call is chained with a
another core services API where we setup to hydrate (or get all details) 
which are then later accessed through another Lambda.
------------------------------------------------------------------
input: policy #, transactionId, caller
output: accessGranted, transactionId
------------------------------------------------------------------
Created By  - VH, EP
Release     - Version 3
Date        - 9/22/23
****************************************************************/

import https from 'node:https';

const ODS_API_BASE_URL = process.env.ODS_API_BASE_URL; 
const ODS_API_USERNAME = process.env.ODS_API_USERNAME;
const ODS_API_PASSWORD = process.env.ODS_API_PASSWORD;
const AUTHORIZATION = `Basic ${Buffer.from(`${ODS_API_USERNAME}:${ODS_API_PASSWORD}`).toString('base64')}`;
const REQUEST_OPTIONS = {
    method: 'GET',
    headers: {
        'Authorization': AUTHORIZATION,
        'Content-Type': 'application/json'
    }
};

const buildEndpoints = (tid, pid, caller) => {
    const singleEndpoint = `/policy/${caller.toLowerCase()}/transaction/${tid}/single/policy/${pid}`;
    const hydrateEndpoint = `/policy/hydrate/policy/transaction/${tid}`;
    
    return { singleEndpoint, hydrateEndpoint };
};

const callSinglePolicy = async (url) => {
    const result = await sendHttpsRequest(url);
    const parsedResult = JSON.parse(result);
    
    console.log(parsedResult);
    
    if (!parsedResult || !parsedResult.accessGranted) throw new Error('access denied');
    if (parsedResult.errorDetails) throw new Error('server error');
};

const callHydratePolicy = async (url) => {
    await sendHttpsRequest(url);
};

const sendHttpsRequest = (url) => new Promise((resolve, reject) => {
    const cb = (res) => {
        if (res.statusCode < 200 || res.statusCode > 299) {
            reject(new Error('bad response'));
            return;
        }

        let data = '';

        res.on('data', (chunk) => data += chunk);
        res.on('end', () => resolve(data));
    };

    const req = https.request(url, REQUEST_OPTIONS, cb);
    req.on('error', (err) => reject(err));
    req.end();
});

export const handler = async (event) => {
    // Parse event
    const { Details: { Parameters: params } = {} } = event;
    const { input_transactionId: transactionId, input_policy_Id: policyId, input_caller: caller } = params;

    // Get endpoints
    const { singleEndpoint, hydrateEndpoint } = buildEndpoints(transactionId, policyId, caller);
    
    // Build urls
    const singleUrl = ODS_API_BASE_URL + singleEndpoint;
    const hydrateUrl = ODS_API_BASE_URL + hydrateEndpoint;
    
    // Connect doesn't read booleans
    let accessGranted = 'true';
    
    try {
        await callSinglePolicy(singleUrl);
        await callHydratePolicy(hydrateUrl);
    } catch(e) {
        console.error(e);
        accessGranted = 'false';
    }

    return { transactionId, accessGranted };
};